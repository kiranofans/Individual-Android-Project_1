package Model;

public interface Base_Items_Model {
    int getViewType();
}
