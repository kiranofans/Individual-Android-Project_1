package Model;

import android.app.AlertDialog;

public abstract class AlertDialogBase {
    public static AlertDialog getAlertDialog() {
        return null;
    }

}
