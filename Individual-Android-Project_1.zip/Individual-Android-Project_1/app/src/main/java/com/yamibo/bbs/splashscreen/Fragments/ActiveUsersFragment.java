package com.yamibo.bbs.splashscreen.Fragments;

import android.support.v4.app.Fragment;

public class ActiveUsersFragment extends Fragment {
    public ActiveUsersFragment(){}
}
