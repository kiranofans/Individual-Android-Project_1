# Individual-Android-Project_1

A Native Android Mobile Application for An Existing Website.

Creating on my own.

May have some unrelated code which can be references.
